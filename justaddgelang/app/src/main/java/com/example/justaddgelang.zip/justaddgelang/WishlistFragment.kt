package com.example.justaddgelang

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class WishlistFragment : Fragment() {

  //  private lateinit var totalPriceTextView: TextView
    private lateinit var wishlistRecyclerView: RecyclerView
    private lateinit var wishlistAdapter: WishlistAdapter
    private var wishlistItems = mutableListOf<CartItem>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_wishlist, container, false)

        // Initialize your views here
     //   totalPriceTextView = view.findViewById(R.id.total_price) // Make sure this is initialized
        wishlistRecyclerView = view.findViewById(R.id.wishlistRecyclerView)

        wishlistRecyclerView.layoutManager = LinearLayoutManager(context)
        wishlistAdapter = WishlistAdapter(wishlistItems) {
          //  updateTotalPrice()
        }
        wishlistRecyclerView.adapter = wishlistAdapter

        loadWishlistItems()  // Assuming this method loads the items into the wishlist

        return view
    }

    private fun loadWishlistItems() {
        // Your code to load items into the wishlist
        wishlistItems.clear()
        wishlistItems.addAll(
            listOf(
                CartItem(Product(1, "Bridgerton Necklace", 250.0, 10, R.drawable.bridgertonnecklace, 1), 1),
                CartItem(Product(2, "Beaded Heart Charm", 100.0, 5, R.drawable.beadedheartcharm, 3), 3)
            )
        )
        wishlistAdapter.notifyDataSetChanged()
       // updateTotalPrice()  // Update total price after loading items
    }

//    private fun updateTotalPrice() {
//        val totalPrice = wishlistItems.sumOf { it.product.productPrice * it.quantity }
//        totalPriceTextView.text = "Total: ₹${"%.2f".format(totalPrice)}"
//    }
}
