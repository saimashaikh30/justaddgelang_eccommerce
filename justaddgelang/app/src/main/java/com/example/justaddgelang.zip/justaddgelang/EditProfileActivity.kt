package com.example.justaddgelang

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class EditProfileActivity : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etPhoneNumber: EditText
    private lateinit var etEmail: EditText
    private lateinit var btnSave: Button
    private lateinit var context: Context

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        context = this

        // Initialize views
        etUsername = findViewById(R.id.etUsername)
        etPhoneNumber = findViewById(R.id.etPhoneNumber)
        etEmail = findViewById(R.id.etEmail)
        btnSave = findViewById(R.id.btnSave)

        // Pre-fill the fields with current user data from SharedPreferences
        etUsername.setText(SharedPreferencesHelper.getUsername(this))
        etPhoneNumber.setText(SharedPreferencesHelper.getPhoneNumber(this))
        etEmail.setText(SharedPreferencesHelper.getEmail(this))

        // Handle Save button click
        btnSave.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val phoneNumber = etPhoneNumber.text.toString().trim()
            val email = etEmail.text.toString().trim()

            if (username.isEmpty() || phoneNumber.isEmpty() || email.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            } else {
                // Save updated profile information
                SharedPreferencesHelper.saveUserData(this, true, "userId", username, "password", phoneNumber, email,"user")

                Toast.makeText(this, "Profile updated successfully", Toast.LENGTH_SHORT).show()

                // Go back to ProfileActivity
                startActivity(Intent(this, ProfileActivity::class.java))
                finish()
            }
        }
    }
}
