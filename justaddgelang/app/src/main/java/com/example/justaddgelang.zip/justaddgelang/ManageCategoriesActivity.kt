package com.example.justaddgelang

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ManageCategoriesActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var btnAddCategory: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var categoryAdapter: AdminCategoryAdapter
    private var categoryList: MutableList<Category> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_category)

        recyclerView = findViewById(R.id.recyclerViewCategories)
        btnAddCategory = findViewById(R.id.btnAddCategory)
        //progressBar = findViewById(R.id.progressBar)

        // Setup RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        categoryAdapter = AdminCategoryAdapter(categoryList, this)
        recyclerView.adapter = categoryAdapter

        // Fetch categories from API or database
        fetchCategories()

        // Add category button listener
        btnAddCategory.setOnClickListener {
            startActivity(Intent(this, AddCategoryActivity::class.java))
        }
    }

    private fun fetchCategories() {
        // Show loading
        progressBar.visibility = View.VISIBLE

        // Simulate fetching categories from a database or API
        categoryList.clear()
        categoryList.addAll(
            listOf(
                Category(1, "Necklace"),
                Category(2, "Bracelet"),
                Category(3, "Earrings")
            )
        )

        // Notify adapter and hide progress bar
        categoryAdapter.notifyDataSetChanged()
        progressBar.visibility = View.GONE
    }
}
