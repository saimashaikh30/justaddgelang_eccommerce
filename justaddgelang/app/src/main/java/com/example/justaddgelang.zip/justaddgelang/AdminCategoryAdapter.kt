package com.example.justaddgelang

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AdminCategoryAdapter(
    private var categoryList: MutableList<Category>,
    private val context: Context
) : RecyclerView.Adapter<AdminCategoryAdapter.CategoryViewHolder>() {

    class CategoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val categoryName: TextView = view.findViewById(R.id.tvCategoryName)
        val btnEdit: Button = view.findViewById(R.id.btnEdit)
        val btnDelete: Button = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_category_admin, parent, false)
        return CategoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        val category = categoryList[position]
        holder.categoryName.text = category.category_name

        // Edit button functionality
        holder.btnEdit.setOnClickListener {
            val intent = Intent(context, EditCategoryActivity::class.java)
            intent.putExtra("CATEGORY_ID", category.category_id)
            context.startActivity(intent)
        }

        // Delete button functionality
        holder.btnDelete.setOnClickListener {
            deleteCategory(position)
        }
    }

    override fun getItemCount(): Int = categoryList.size

    private fun deleteCategory(position: Int) {
        categoryList.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, categoryList.size)
    }
}
