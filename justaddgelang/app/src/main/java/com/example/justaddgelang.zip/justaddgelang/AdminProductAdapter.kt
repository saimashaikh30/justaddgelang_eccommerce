package com.example.justaddgelang

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class AdminProductAdapter(
    private var productList: MutableList<Product>,
    private val context: Context
) : RecyclerView.Adapter<AdminProductAdapter.ProductViewHolder>() {

    class ProductViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val productName: TextView = view.findViewById(R.id.tvProductName)
        val productPrice: TextView = view.findViewById(R.id.tvProductPrice)
        val btnEdit: ImageButton = view.findViewById(R.id.btnEdit)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDelete)
        val image: ImageView=view.findViewById(R.id.ivProductImage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_product_admin, parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = productList[position]
        holder.productName.text = product.productName
        holder.productPrice.text = "₹${product.productPrice}"
        holder.image.setImageResource(product.imageUrl)

        holder.btnEdit.setOnClickListener {
            val intent = Intent(context, EditProductActivity::class.java)
            intent.putExtra("PRODUCT_ID", product.productId)
            context.startActivity(intent)
        }

        holder.btnDelete.setOnClickListener {
            deleteProduct(position)
        }
    }

    override fun getItemCount(): Int = productList.size

    private fun deleteProduct(position: Int) {
        productList.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, productList.size) // Ensures proper UI update
        Toast.makeText(context, "Product Deleted", Toast.LENGTH_SHORT).show()
    }
}
