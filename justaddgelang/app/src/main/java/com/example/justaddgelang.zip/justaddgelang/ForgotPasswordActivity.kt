package com.example.justaddgelang

import android.content.Context
import android.os.Bundle
import android.telephony.SmsManager
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.justaddgelang.SharedPreferencesHelper
import java.util.*
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat



class ForgotPasswordActivity : AppCompatActivity() {

    private lateinit var tvPhoneNumber: TextView
    private lateinit var etOtp: EditText
    private lateinit var btnVerifyOtp: Button
    private lateinit var etPhoneNumber: EditText
    private lateinit var btnSendOtp: Button
    private lateinit var context: Context

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.forgot_password)

        context = this

        // Initialize views
        tvPhoneNumber = findViewById(R.id.tvOtpMessage)
        etOtp = findViewById(R.id.etOTP)
        btnVerifyOtp = findViewById(R.id.btnVerifyOTP)
        etPhoneNumber = findViewById(R.id.etPhoneNumber)  // EditText for entering phone number
        btnSendOtp = findViewById(R.id.btnSendOtp)  // Button to send OTP

        // Handle Send OTP button click
        btnSendOtp.setOnClickListener {
            val phoneNumber = etPhoneNumber.text.toString().trim()
            if (phoneNumber.isEmpty()) {
                Toast.makeText(this, "Please enter phone number", Toast.LENGTH_SHORT).show()
            } else {
                // Send OTP to the entered phone number
                sendOtp(phoneNumber)
            }
        }

        // Handle OTP verification
        btnVerifyOtp.setOnClickListener {
            val otp = etOtp.text.toString().trim()
            if (otp.isEmpty()) {
                Toast.makeText(this, "Please enter OTP", Toast.LENGTH_SHORT).show()
            } else {
                // Handle OTP verification logic
                verifyOtp(otp)
            }
        }
    }

    private fun sendOtp(phoneNumber: String) {
        // Generate a 6-digit OTP
        val otp = (100000..999999).random().toString()

        // Send OTP via SMS
        val message = "Your OTP code is: $otp"
        sendSms(phoneNumber, message, context)

        // Display OTP message with the last 4 digits of the phone number
        val lastFourDigits = phoneNumber.takeLast(4)
        tvPhoneNumber.text = "OTP sent to ****$lastFourDigits"

        // Optionally, store OTP for later verification (e.g. in SharedPreferences, or directly pass to backend)
        // Here, we are just saving it temporarily in SharedPreferences for demonstration.
        val sharedPreferences = getSharedPreferences("user_preferences", Context.MODE_PRIVATE)
        sharedPreferences.edit().putString("otp", otp).apply()

        // Hide the phone number input and show OTP input fields
        etPhoneNumber.visibility = View.GONE
        btnSendOtp.visibility = View.GONE
        etOtp.visibility = View.VISIBLE
        btnVerifyOtp.visibility = View.VISIBLE
    }

    private fun verifyOtp(otp: String) {
        // Fetch the OTP from SharedPreferences and compare
        val sharedPreferences = getSharedPreferences("user_preferences", Context.MODE_PRIVATE)
        val savedOtp = sharedPreferences.getString("otp", null)

        if (savedOtp != null && savedOtp == otp) {
            Toast.makeText(this, "OTP Verified Successfully!", Toast.LENGTH_SHORT).show()

            // Proceed to the password change activity
            val intent = Intent(this, ChangePasswordActivity::class.java)
            startActivity(intent)
            finish()  // Optionally close the current activity if you don't want to go back
        } else {
            Toast.makeText(this, "Invalid OTP", Toast.LENGTH_SHORT).show()
        }
    }


    private fun sendSms(phoneNumber: String, message: String, context: Context) {
        try {
            // Check if phone number is valid
            if (phoneNumber.isNotEmpty() && phoneNumber.length >= 10) {
                val smsManager = SmsManager.getDefault()
                smsManager.sendTextMessage(phoneNumber, null, message, null, null)
                Toast.makeText(context, "OTP sent successfully!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Invalid phone number", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            // Handle the exception and log it
            Toast.makeText(context, "Failed to send SMS: ${e.message}", Toast.LENGTH_SHORT).show()
           //  Log.e("SMS", "Error: ${e.message}")
        }
    }


    // In your ForgotPasswordActivity, request permissions if needed

    private fun checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS), 1)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, now you can send the SMS
            } else {
                Toast.makeText(this, "Permission denied to send SMS", Toast.LENGTH_SHORT).show()
            }
        }
    }

}
