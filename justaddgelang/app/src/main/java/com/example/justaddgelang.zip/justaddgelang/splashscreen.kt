package com.example.justaddgelang

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    private lateinit var typingText: TextView
    private val fullText = "justaddgelang"
    private var index = 0
    private val typingDelay: Long = 150 // Speed of typing (milliseconds)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splashscreen)

        typingText = findViewById(R.id.typing_text)
        startTypingEffect()

        // Delay transitioning to MainActivity after typing finishes
        Handler().postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, fullText.length * typingDelay + 1000) // Delay a bit after animation completes
    }

    private fun startTypingEffect() {
        val handler = Handler()
        Handler().postDelayed({
            val isLoggedIn = SharedPreferencesHelper.isLoggedIn(this)
            val userType = SharedPreferencesHelper.getUsertype(this)

            val intent = when {
                isLoggedIn && userType == "admin" -> Intent(this, AdminHomePageActivity::class.java)
                isLoggedIn && userType == "user" -> Intent(this, MainActivity::class.java)
                else -> Intent(this, Login::class.java)
            }

            startActivity(intent)
            finish()
        }, fullText.length * typingDelay + 1000)

    }
}
