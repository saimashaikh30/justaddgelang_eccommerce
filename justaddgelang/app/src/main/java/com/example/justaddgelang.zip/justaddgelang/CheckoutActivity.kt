package com.example.justaddgelang

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class CheckoutActivity : AppCompatActivity() {

    private lateinit var totalPriceTextView: TextView
    private lateinit var addressSpinner: Spinner
    private lateinit var paymentMethodSpinner: Spinner
    private lateinit var btnPlaceOrder: Button

    private var totalAmount: Double = 0.0 // Total amount passed from CartFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)

        // Initialize views
        totalPriceTextView = findViewById(R.id.tvTotalPrice)
        addressSpinner = findViewById(R.id.spinnerAddress)
        paymentMethodSpinner = findViewById(R.id.spinnerPaymentMethod)
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder)

        // Get total price from intent
        totalAmount = intent.getDoubleExtra("TOTAL_PRICE", 0.0)
        totalPriceTextView.text = "Total: ₹${"%.2f".format(totalAmount)}"

        // Populate Address Spinner with dummy addresses
        val addressList = listOf(
            "John Doe, 123 Street, City, 560001",
            "Jane Smith, 45A Block, Town, 110092",
            "Mike Johnson, 789 Lane, Metro, 400001",
            "Emily Davis, 56B Avenue, Suburb, 700045"
        )
        val addressAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, addressList)
        addressAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        addressSpinner.adapter = addressAdapter

        // Populate Payment Method Spinner
        val paymentMethods = listOf("Credit/Debit Card", "Net Banking", "UPI", "Cash on Delivery")
        val paymentAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, paymentMethods)
        paymentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        paymentMethodSpinner.adapter = paymentAdapter

        // Place Order button click event
        btnPlaceOrder.setOnClickListener {
            val selectedAddress = addressSpinner.selectedItem.toString()
            val selectedPaymentMethod = paymentMethodSpinner.selectedItem.toString()

            if (selectedAddress.isNotEmpty() && selectedPaymentMethod.isNotEmpty()) {
                Toast.makeText(this, "Order Placed Successfully!", Toast.LENGTH_LONG).show()

                // Navigate to Order Confirmation Activity
                val intent = Intent(this, OrderConfirmationActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Please select an address and payment method", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
