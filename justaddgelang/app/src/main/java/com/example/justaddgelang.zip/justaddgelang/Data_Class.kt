package com.example.justaddgelang
data class LoginResponse(
    val success: Boolean,
    val message: String?,
    val user: User?
)

data class User(
    val user_id: Int?,
    val username: String?,
    val password: String?,
    val usertype: String?,
    val phone_no: String?,
    val email_id: String?
)


data class RegistrationResponse(
    val success: Boolean,
    val message: String,
    val user: User
)

data class Category(
    var category_id: Int?,
    var category_name: String
)

data class Product(
    val productId: Int,
    var productName: String,
    var productPrice: Double,
    var productStock: Int,
    var imageUrl: Int,  // Assuming the image is stored as a resource ID
    val categoryId: Int
)


data class CartItem(
    val product: Product,
    var quantity: Int
)
data class Order(
    val order_id: Int,
    val order_date: String,
    var order_status: String,
    val total_amount: Double,
    val order_items: List<OrderItem>
)

data class OrderItem(
    val product_name: String,
    val quantity: Int,
    val price: Double
)




