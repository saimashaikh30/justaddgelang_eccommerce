package com.example.justaddgelang

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface ApiService {
    @POST("api/login")
    fun login(@Body request: LoginRequest): Call<LoginResponse>

    @POST("api/login/register")  // This matches the controller's route
    fun registerUser(@Body user: User): Call<UserResponse>

    @GET("api/category")
    fun getCategories(): Call<List<Category>>

    @GET("api/products")
    fun getProducts(): Call<List<Product>>// Changed method name to match more clearly
}
