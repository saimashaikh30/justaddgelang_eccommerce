package com.example.justaddgelang

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class OrderConfirmationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_confirmation)

        val tvOrderSuccess: TextView = findViewById(R.id.tvOrderSuccess)
        val tvOrderDetails: TextView = findViewById(R.id.tvOrderDetails)
        val btnContinueShopping: Button = findViewById(R.id.btnContinueShopping)

        // Display order success message
        tvOrderSuccess.text = "🎉 Order Placed Successfully! 🎉"
        tvOrderDetails.text = "Thank you for shopping with us! Your order will be processed shortly."

        // Redirect to home or shopping page
        btnContinueShopping.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java) // Change MainActivity to your home screen
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish()
        }
    }
}
