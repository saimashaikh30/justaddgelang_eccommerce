package com.example.justaddgelang

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ManageProductsActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var btnAddProduct: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var adminProductAdapter: AdminProductAdapter
    private var productList = mutableListOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_products)

        recyclerView = findViewById(R.id.recyclerViewProducts)
        btnAddProduct = findViewById(R.id.btnAddProduct)
        progressBar = findViewById(R.id.progressBar)

        recyclerView.layoutManager = LinearLayoutManager(this)

        // Initialize adapter with fake data
        productList = generateFakeProducts()
        adminProductAdapter = AdminProductAdapter(productList, this)
        recyclerView.adapter = adminProductAdapter

        btnAddProduct.setOnClickListener {
            startActivity(Intent(this, AddProductActivity::class.java))
        }
    }

    private fun generateFakeProducts(): MutableList<Product> {
        return mutableListOf(
            Product(1, "Bridgerton Necklace", 250.0, 10, R.drawable.bridgertonnecklace, 1),
            Product(2, "Beaded Heart Charm", 100.0, 5, R.drawable.beadedheartcharm, 3),
            Product(3, "Beaded Heart Rings", 120.0, 4, R.drawable.beadedheartrings, 1),
            Product(4, "Reputation Keychain", 90.0, 3, R.drawable.beadedheartkeychain, 3),
            Product(5, "Daisy Hoops", 130.0, 10, R.drawable.daisyhoops, 2),
            Product(6, "Stellar Necklace", 180.0, 5, R.drawable.stellarnecklace, 2),
            Product(7, "Stawberry Earrings ", 130.0, 5, R.drawable.stawberryearrings, 4),
            Product(8, "Multicolor daisy Hoops", 180.0, 5, R.drawable.multicoloureddaisyhoops, 2)
        )
    }
}
