package com.example.justaddgelang

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WishlistAdapter(
    private val wishlist: MutableList<CartItem>,  // Make the wishlist mutable
    private val updateTotalPrice: () -> Unit
) : RecyclerView.Adapter<WishlistAdapter.WishlistViewHolder>() {

    class WishlistViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.product_image)
        val name: TextView = view.findViewById(R.id.product_name)
        val price: TextView = view.findViewById(R.id.product_price)
      //  val quantity: TextView = view.findViewById(R.id.product_quantity)
        val removeButton: ImageButton = view.findViewById(R.id.heart_button)  // Change to ImageButton
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WishlistViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_wishlist, parent, false)
        return WishlistViewHolder(view)
    }

    override fun onBindViewHolder(holder: WishlistViewHolder, position: Int) {
        val item = wishlist[position]

        holder.name.text = item.product.productName
        holder.price.text = "₹${item.product.productPrice}"
      //  holder.quantity.text = "Quantity: ${item.quantity}"

        // Set image from drawable
        holder.image.setImageResource(item.product.imageUrl)

        // Set a heart icon for the remove button (ImageButton)
        holder.removeButton.setImageResource(R.drawable.baseline_favorite_24)  // Set heart icon for remove button

        holder.removeButton.setOnClickListener {
            wishlist.removeAt(position)  // Remove item at the clicked position
            notifyItemRemoved(position)  // Notify adapter about item removal
            updateTotalPrice()  // Update total price after removal
        }
    }

    override fun getItemCount(): Int {
        return wishlist.size
    }
}
