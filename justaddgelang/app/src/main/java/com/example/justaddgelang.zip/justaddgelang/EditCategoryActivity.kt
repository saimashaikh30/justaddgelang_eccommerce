package com.example.justaddgelang

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class EditCategoryActivity : AppCompatActivity() {

    private lateinit var etCategoryName: EditText
    private lateinit var btnSaveCategory: Button
    private lateinit var category: Category

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_category)

        // Initialize views
        etCategoryName = findViewById(R.id.etCategoryName)
        btnSaveCategory = findViewById(R.id.btnSaveCategory)

        // Get the category ID passed from the previous activity (category ID will be passed from AdminCategoryAdapter)
        val categoryId = intent.getIntExtra("CATEGORY_ID", -1)
        category = getCategoryById(categoryId)

        // Pre-fill the EditText with the current category name
        etCategoryName.setText(category.category_name)

        // Set listener for save button
        btnSaveCategory.setOnClickListener {
            saveCategory()
        }
    }

    private fun getCategoryById(categoryId: Int): Category {
        // Retrieve the category from your data source (this can be a database, API, or local list)
        // For now, we'll return a placeholder category
        return Category(categoryId, "Sample Category")
    }

    private fun saveCategory() {
        // Get the updated category name from the EditText
        val updatedCategoryName = etCategoryName.text.toString().trim()

        if (updatedCategoryName.isEmpty()) {
            Toast.makeText(this, "Please enter a category name", Toast.LENGTH_SHORT).show()
            return
        }

        // Update the category object with the new name
        category.category_name = updatedCategoryName

        // Simulate saving the updated category (can be replaced with actual saving logic)
        updateCategoryOnServer(category)

        // Show success message and finish activity
        Toast.makeText(this, "Category updated successfully!", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun updateCategoryOnServer(updatedCategory: Category) {
        // Implement the logic to update the category on the server or local database
        // This is a placeholder function
    }
}
