package com.example.justaddgelang

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.io.ByteArrayInputStream

class ProductAdapter(
    private val productList: List<Product>,
    private val onItemClick: (Product) -> Unit // Add click listener as a parameter
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    // ViewHolder class
    class ProductViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.product_image)
        val name: TextView = view.findViewById(R.id.product_name)
        val price: TextView = view.findViewById(R.id.product_price)
    }

    // Base64 to Bitmap conversion method
    private fun base64ToBitmap(base64String: String?): Bitmap? {
        if (base64String.isNullOrEmpty()) {
            Log.e("ProductAdapter", "Base64 string is null or empty")
            return null
        }

        return try {
            val decodedBytes = Base64.decode(base64String, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeStream(ByteArrayInputStream(decodedBytes))
            if (bitmap == null) {
                Log.e("ProductAdapter", "Failed to decode the Base64 string into a bitmap")
            }
            bitmap
        } catch (e: Exception) {
            Log.e("ProductAdapter", "Error decoding Base64 string", e)
            null
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = productList[position]

        holder.name.text = product.productName
        holder.price.text = "₹${product.productPrice}"

        // Set up the image (consider using Glide or Picasso for better image handling)
        Glide.with(holder.itemView.context)
            .load(product.imageUrl)
            .into(holder.image)

        // Set up the click listener
        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, ProductDetailActivity::class.java).apply {
                putExtra("product_name", product.productName)
                putExtra("product_price", product.productPrice)
                putExtra("product_image", product.imageUrl) // Or Base64 if needed
            }
            holder.itemView.context.startActivity(intent)
        }
    }


    override fun getItemCount(): Int {
        return productList.size
    }
}
