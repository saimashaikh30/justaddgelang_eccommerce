package com.example.justaddgelang

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProductDetailActivity : AppCompatActivity() {

    private lateinit var productImage: ImageView
    private lateinit var productName: TextView
    private lateinit var productPrice: TextView
    private lateinit var addToCartButton: ImageButton
    private lateinit var addToWishlistButton: ImageButton
    private lateinit var reviewTextInput: EditText
    private lateinit var submitReviewButton: Button

    private lateinit var star1: ImageButton
    private lateinit var star2: ImageButton
    private lateinit var star3: ImageButton
    private lateinit var star4: ImageButton
    private lateinit var star5: ImageButton
    private lateinit var reviewsContainer: LinearLayout

    private var selectedRating = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.product_detail)

        // Initialize Views
        productImage = findViewById(R.id.product_image)
        productName = findViewById(R.id.product_name)
        productPrice = findViewById(R.id.product_price)
        addToCartButton = findViewById(R.id.add_to_cart_button)
        addToWishlistButton = findViewById(R.id.add_to_wishlist_button)
        reviewTextInput = findViewById(R.id.review_text_input)
        submitReviewButton = findViewById(R.id.submit_review_button)

        star1 = findViewById(R.id.star_1)
        star2 = findViewById(R.id.star_2)
        star3 = findViewById(R.id.star_3)
        star4 = findViewById(R.id.star_4)
        star5 = findViewById(R.id.star_5)
        reviewsContainer = findViewById(R.id.reviews_container)

        // Retrieve the product data from the Intent
        val productNameText = intent.getStringExtra("product_name") ?: "Unknown"
        val productPriceText = intent.getStringExtra("product_price") ?: "250.0"
        val productImageResId = intent.getIntExtra("product_image", R.drawable.beadedheartrings)

        // Display the product details
        productName.text = productNameText
        productPrice.text = productPriceText
        productImage.setImageResource(productImageResId)

        // Handle Add to Cart Button Click
        addToCartButton.setOnClickListener {
            // Handle adding to cart logic here
        }

        // Handle Add to Wishlist Button Click
        addToWishlistButton.setOnClickListener {
            // Handle adding to wishlist logic here
        }

        // Handle Rating Button Clicks
        star1.setOnClickListener { setRating(1) }
        star2.setOnClickListener { setRating(2) }
        star3.setOnClickListener { setRating(3) }
        star4.setOnClickListener { setRating(4) }
        star5.setOnClickListener { setRating(5) }

        // Handle Submit Review Button Click
        submitReviewButton.setOnClickListener {
            val reviewText = reviewTextInput.text.toString()
            if (reviewText.isNotEmpty()) {
                submitReview(selectedRating, reviewText)
            }
        }
    }

    private fun setRating(rating: Int) {
        selectedRating = rating
        updateStarRating(rating)
    }

    private fun updateStarRating(selectedRating: Int) {
        val stars = listOf(star1, star2, star3, star4, star5)
        for (i in stars.indices) {
            if (i < selectedRating) {
                stars[i].setImageResource(R.drawable.star_filled) // Filled star
            } else {
                stars[i].setImageResource(R.drawable.star_empty)  // Empty star
            }
        }
    }

    private fun submitReview(rating: Int, reviewText: String) {
        // Here, you would normally send the review data to your backend or save it locally
        val review = Review(rating, reviewText)

        // Add the review to the reviews container (You can make it dynamic here)
        val reviewView = createReviewView(review)
        reviewsContainer.addView(reviewView)

        // Clear the review input after submission
        reviewTextInput.text.clear()
    }

    private fun createReviewView(review: Review): View {
        // Create a custom layout for each review
        val reviewLayout = layoutInflater.inflate(R.layout.review_item, reviewsContainer, false)
        val reviewRating = reviewLayout.findViewById<TextView>(R.id.review_rating)
        val reviewText = reviewLayout.findViewById<TextView>(R.id.review_text)

        reviewRating.text = "${review.rating} stars"
        reviewText.text = review.text

        return reviewLayout
    }

    data class Review(val rating: Int, val text: String)
}
