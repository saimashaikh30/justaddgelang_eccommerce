package com.example.justaddgelang

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AddAddressActivity : AppCompatActivity() {

    private lateinit var etAddress: EditText
    private lateinit var etCity: EditText
    private lateinit var etState: EditText
    private lateinit var etPostalCode: EditText
    private lateinit var spinnerAddressType: Spinner
    private lateinit var btnSaveAddress: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_address)

        // Initialize views
        etAddress = findViewById(R.id.etAddress)
        etCity = findViewById(R.id.etCity)
        etState = findViewById(R.id.etState)
        etPostalCode = findViewById(R.id.etPostalCode)
        spinnerAddressType = findViewById(R.id.spinnerAddressType)
        btnSaveAddress = findViewById(R.id.btnSaveAddress)

        // Set up the spinner with address types
        val addressTypes = arrayOf("Home", "Office", "Other")
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, addressTypes)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerAddressType.adapter = spinnerAdapter

        // Handle Save Address button click
        btnSaveAddress.setOnClickListener {
            val address = etAddress.text.toString().trim()
            val city = etCity.text.toString().trim()
            val state = etState.text.toString().trim()
            val postalCode = etPostalCode.text.toString().trim()
            val addressType = spinnerAddressType.selectedItem.toString()

            if (address.isEmpty() || city.isEmpty() || state.isEmpty() || postalCode.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            } else {
                // Save the address (this can be saved to SharedPreferences or a database)
                Toast.makeText(this, "Address saved: $address, $city, $state, $postalCode, Type: $addressType", Toast.LENGTH_SHORT).show()
                finish() // Close the activity after saving
            }
        }
    }
}
