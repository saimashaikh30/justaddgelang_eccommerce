package com.example.justaddgelang

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ManageOrdersActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var orderAdapter: OrderAdapter
    private var orderList = mutableListOf<Order>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_orders)

        recyclerView = findViewById(R.id.recyclerViewOrders)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Initialize the adapter, but don't pass the list yet
        orderAdapter = OrderAdapter(this)

        recyclerView.adapter = orderAdapter

        // Simulate fetching orders
        fetchOrders()
    }

    private fun fetchOrders() {
        orderList = generateFakeOrders()  // Replace this with your actual data fetching logic
        Log.d("ManageOrdersActivity", "Orders Loaded: ${orderList.size}")  // Debug log

        // Update the adapter with the new list of orders
        orderAdapter.setOrders(orderList)
    }

    private fun generateFakeOrders(): MutableList<Order> {
        return mutableListOf(
            Order(
                order_id = 1,
                order_date = "2025-03-01",
                order_status = "Pending",
                total_amount = 150.00,
                order_items = listOf(
                    OrderItem("Product 1", 2, 30.00),
                    OrderItem("Product 2", 1, 90.00)
                )
            ),
            Order(
                order_id = 2,
                order_date = "2025-03-05",
                order_status = "Pending",
                total_amount = 200.00,
                order_items = listOf(
                    OrderItem("Product 3", 3, 60.00),
                    OrderItem("Product 4", 2, 40.00)
                )
            )
        )
    }
}
