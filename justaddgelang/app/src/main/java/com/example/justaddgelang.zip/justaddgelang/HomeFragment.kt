package com.example.justaddgelang
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.util.Log


class HomeFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var productAdapter: ProductAdapter
    private var productList = mutableListOf<Product>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(context, 2)

        productAdapter = ProductAdapter(productList) { product ->
            // Handle item click
            val intent = Intent(context, ProductDetailActivity::class.java)
            // Pass product details via Intent
            intent.putExtra("product_name", product.productName)
            intent.putExtra("product_price", product.productPrice)
            intent.putExtra("product_image", product.imageUrl) // If you're using a drawable resource
            startActivity(intent)
        }

        recyclerView.adapter = productAdapter

        loadFakeProducts() // Load fake products

        return view
    }

    private fun loadFakeProducts() {
        productList.clear()
        productList.addAll(
            listOf(
                Product(1, "Bridgerton Necklace", 250.0, 10, R.drawable.bridgertonnecklace, 1),
                Product(2, "Stawberry Earrings", 130.0, 5, R.drawable.stawberryearrings, 3),
                Product(3, "Beaded Heart Rings", 120.0, 4, R.drawable.beadedheartrings, 1),
                Product(4, "Reputation Keychain", 90.0, 3, R.drawable.beadedheartkeychain, 3),
                Product(5, "Daisy Hoops", 130.0, 10, R.drawable.daisyhoops, 2),
                Product(6, "Stellar Necklace", 180.0, 5, R.drawable.stellarnecklace, 2)
            )
        )
        productAdapter.notifyDataSetChanged()
    }
}
