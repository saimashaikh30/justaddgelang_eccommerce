package com.example.justaddgelang

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.ActivityResultLauncher

class AddProductActivity : AppCompatActivity() {

    private lateinit var etProductName: EditText
    private lateinit var etProductPrice: EditText
    private lateinit var etProductQuantity: EditText
    private lateinit var btnPickImage: Button
    private lateinit var btnSaveProduct: Button
    private var selectedImageUri: Uri? = null

    private lateinit var imagePickerLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_product)

        // Initialize Views
        etProductName = findViewById(R.id.etProductName)
        etProductPrice = findViewById(R.id.etProductPrice)
        etProductQuantity = findViewById(R.id.etProductQuantity)
        btnPickImage = findViewById(R.id.btnPickImage)
        btnSaveProduct = findViewById(R.id.btnSaveProduct)

        // Set up the image picker launcher
        imagePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                selectedImageUri = result.data?.data
                // You can show a preview of the image here if desired
            }
        }

        // Button to pick an image from the gallery
        btnPickImage.setOnClickListener {
            openImagePicker()
        }

        // Button to save the product
        btnSaveProduct.setOnClickListener {
            saveProduct()
        }
    }

    // Open the image picker (gallery)
    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        imagePickerLauncher.launch(intent)
    }

    // Save product logic
    private fun saveProduct() {
        val productName = etProductName.text.toString().trim()
        val productPrice = etProductPrice.text.toString().trim()
        val productQuantity = etProductQuantity.text.toString().trim()

        if (productName.isEmpty() || productPrice.isEmpty() || productQuantity.isEmpty() || selectedImageUri == null) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val price = productPrice.toDouble()
        val quantity = productQuantity.toInt()

        // Create a new Product object
        val newProduct = Product(
            productId = 0,  // We'll assume the backend will handle the ID assignment
            productName = productName,
            productPrice = price,
            productStock = quantity,
            imageUrl = R.drawable.shellstackbracelet,
            categoryId = 1  // Assuming default category, change as needed
        )

        // Add the product to the list or send it to the server
        // For example, using a mock method to add product:
        addProductToServer(newProduct)
    }

    // Mock method to simulate adding a product to the server
    private fun addProductToServer(product: Product) {
        // In a real-world app, you would send the product object to your backend API
        // For now, let's show a success message
        Toast.makeText(this, "Product added successfully!", Toast.LENGTH_SHORT).show()
        finish()  // Close the activity after saving
    }
}
