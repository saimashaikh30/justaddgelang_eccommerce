package com.example.justaddgelang

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CartAdapter(
    private val cartList: List<CartItem>,
    private val updateTotalPrice: () -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    class CartViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.cart_product_image)
        val name: TextView = view.findViewById(R.id.cart_product_name)
        val price: TextView = view.findViewById(R.id.cart_product_price)
        val quantity: TextView = view.findViewById(R.id.cart_quantity)
        val btnIncrease: Button = view.findViewById(R.id.btn_increase)
        val btnDecrease: Button = view.findViewById(R.id.btn_decrease)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cart, parent, false)
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val cartItem = cartList[position]
        val product = cartItem.product

        holder.name.text = product.productName
        holder.price.text = "₹${"%.2f".format(product.productPrice * cartItem.quantity)}"
        holder.image.setImageResource(product.imageUrl)
        holder.quantity.text = cartItem.quantity.toString()

        holder.btnIncrease.setOnClickListener {
            cartItem.quantity++
            holder.quantity.text = cartItem.quantity.toString()
            holder.price.text = "₹${"%.2f".format(product.productPrice * cartItem.quantity)}"
            updateTotalPrice()
        }

        holder.btnDecrease.setOnClickListener {
            if (cartItem.quantity > 1) {
                cartItem.quantity--
                holder.quantity.text = cartItem.quantity.toString()
                holder.price.text = "₹${"%.2f".format(product.productPrice * cartItem.quantity)}"
                updateTotalPrice()
            }
        }
    }

    override fun getItemCount(): Int {
        return cartList.size
    }
}
