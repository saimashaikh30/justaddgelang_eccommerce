package com.example.justaddgelang

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AddressActivity : AppCompatActivity() {

    private lateinit var addressListView: ListView
    private lateinit var btnAddAddress: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_address)

        // Initialize views
        addressListView = findViewById(R.id.addressListView)
        btnAddAddress = findViewById(R.id.btnAddAddress)

        // Sample address data (replace with actual data from your storage or database)
        val addresses = arrayOf("123 Main Street, City", "456 Another St, Town", "789 Park Ave, Village")

        // Set up the ListView adapter
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, addresses)
        addressListView.adapter = adapter

        // Handle Add Address button click
        btnAddAddress.setOnClickListener {
            // Open Add Address activity
            startActivity(Intent(this, AddAddressActivity::class.java))
        }

        // Handle item clicks in the address list
        addressListView.setOnItemClickListener { _, _, position, _ ->
            val selectedAddress = addresses[position]
            // You can open a new activity or dialog to edit the selected address
            // For now, just show a Toast with the selected address
            Toast.makeText(this, "Selected address: $selectedAddress", Toast.LENGTH_SHORT).show()
        }
    }
}
