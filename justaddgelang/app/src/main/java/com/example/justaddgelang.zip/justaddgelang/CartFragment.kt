package com.example.justaddgelang

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CartFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var cartAdapter: CartAdapter
    private lateinit var totalPriceTextView: TextView
    private lateinit var checkoutButton: Button
    private var cartList = mutableListOf<CartItem>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_cart, container, false)

        recyclerView = view.findViewById(R.id.cartRecyclerView)
        totalPriceTextView = view.findViewById(R.id.total_price)
        checkoutButton = view.findViewById(R.id.btn_checkout)

        recyclerView.layoutManager = LinearLayoutManager(context)
        cartAdapter = CartAdapter(cartList, ::updateTotalPrice)
        recyclerView.adapter = cartAdapter

        // ✅ Re-enable Checkout Button
//        checkoutButton.setOnClickListener {
//            findNavController().navigate(R.id.action_cartFragment_to_checkoutFragment)
//        }

        checkoutButton.setOnClickListener {
            val intent = Intent(requireContext(), CheckoutActivity::class.java)
            intent.putExtra("TOTAL_PRICE", cartList.sumOf { it.product.productPrice * it.quantity })
            startActivity(intent)
        }

        loadCartItems()

        return view
    }

    private fun loadCartItems() {
        cartList.clear()
        cartList.addAll(
            listOf(
                CartItem(Product(1, "Bridgerton Necklace", 250.0, 10, R.drawable.bridgertonnecklace, 1), 1),
                CartItem(Product(2, "Beaded Heart Charm", 100.0, 5, R.drawable.beadedheartcharm, 3), 2),
                CartItem(Product(3, "Beaded Heart Rings", 120.0, 4, R.drawable.beadedheartrings, 1), 1),
                CartItem(Product(4, "Reputation Keychain", 90.0, 3, R.drawable.beadedheartkeychain, 3), 1),
//                CartItem(Product(5, "Daisy Hoops", 130.0, 10, R.drawable.daisyhoops, 2), 1),
//                CartItem(Product(6, "Stellar Necklace", 180.0,5,R.drawable.stellarnecklace, 2), 2)
            )
        )

        // ✅ Use the instance of cartAdapter
        cartAdapter.notifyDataSetChanged()
        updateTotalPrice()
    }

    private fun updateTotalPrice() {
        val totalPrice = cartList.sumOf { it.product.productPrice * it.quantity }
        totalPriceTextView.text = "Total: ₹${"%.2f".format(totalPrice)}"
    }
}
