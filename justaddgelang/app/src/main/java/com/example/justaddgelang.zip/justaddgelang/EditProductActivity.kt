package com.example.justaddgelang

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.ActivityResultLauncher

class EditProductActivity : AppCompatActivity() {

    private lateinit var etProductName: EditText
    private lateinit var etProductPrice: EditText
    private lateinit var etProductQuantity: EditText
    private lateinit var ivProductImage: ImageView
    private lateinit var btnPickImage: Button
    private lateinit var btnSaveProduct: Button
    private var selectedImageUri: Uri? = null
    private var product: Product? = null

    private lateinit var imagePickerLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_product)

        // Initialize Views
        etProductName = findViewById(R.id.etProductName)
        etProductPrice = findViewById(R.id.etProductPrice)
        etProductQuantity = findViewById(R.id.etProductQuantity)
        ivProductImage = findViewById(R.id.ivProductImage)
        btnPickImage = findViewById(R.id.btnPickImage)
        btnSaveProduct = findViewById(R.id.btnSaveProduct)

        // Get the product details passed from the adapter
        val productId = intent.getIntExtra("PRODUCT_ID", -1)
        product = getProductById(productId)  // Retrieve product from your data source (API or local storage)

        // Pre-fill the fields with product data
        product?.let {
            etProductName.setText(it.productName)
            etProductPrice.setText(it.productPrice.toString())
            etProductQuantity.setText(it.productStock.toString())
            ivProductImage.setImageResource(it.imageUrl)
        }

        // Set up the image picker launcher
        imagePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                selectedImageUri = result.data?.data
                ivProductImage.setImageURI(selectedImageUri)  // Show the selected image as a preview
            }
        }

        // Set button listeners
        btnPickImage.setOnClickListener {
            openImagePicker()
        }

        btnSaveProduct.setOnClickListener {
            saveProduct()
        }
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        imagePickerLauncher.launch(intent)
    }

    private fun saveProduct() {
        val productName = etProductName.text.toString().trim()
        val productPrice = etProductPrice.text.toString().trim()
        val productQuantity = etProductQuantity.text.toString().trim()

        if (productName.isEmpty() || productPrice.isEmpty() || productQuantity.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val price = productPrice.toDouble()
        val quantity = productQuantity.toInt()

        // Update product object with new data
        product?.apply {
            this.productName = productName
            this.productPrice = price
            this.productStock = quantity
            selectedImageUri?.let {
                this.imageUrl = R.drawable.pearlsairpodcase  // Or upload the image if necessary
            }
        }

        // Simulate saving the updated product (via API or local database)
        product?.let { updateProductOnServer(it) }

        // Show a success message
        Toast.makeText(this, "Product updated successfully!", Toast.LENGTH_SHORT).show()
        finish()  // Close activity and return to the previous screen
    }

    private fun getProductById(productId: Int): Product {
        // Retrieve product by ID (you can either fetch from a local database or API)
        // This is a placeholder function, update it to fetch the actual product
        return Product(productId, "Airpods Case", 150.0, 10, R.drawable.pearlsairpodcase, 1)
    }

    private fun updateProductOnServer(updatedProduct: Product) {
        // Implement your API request to update the product in the database
        // For now, this is just a placeholder method
    }
}
