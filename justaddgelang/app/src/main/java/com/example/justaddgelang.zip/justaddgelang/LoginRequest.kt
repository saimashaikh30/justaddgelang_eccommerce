package com.example.justaddgelang
data class LoginRequest(val username: String, val password: String)
