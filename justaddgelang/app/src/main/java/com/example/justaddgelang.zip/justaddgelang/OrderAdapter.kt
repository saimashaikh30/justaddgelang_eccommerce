package com.example.justaddgelang

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class OrderAdapter(private val context: Context) : RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {

    private var orders: List<Order> = listOf()

    inner class OrderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvOrderId: TextView = view.findViewById(R.id.tvOrderId)
        val tvOrderStatus: TextView = view.findViewById(R.id.tvOrderStatus)
        val tvOrderDate: TextView = view.findViewById(R.id.tvOrderDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_order, parent, false)
        return OrderViewHolder(view)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val order = orders[position]
        holder.tvOrderId.text = "Order ID: ${order.order_id}"
        holder.tvOrderStatus.text = "Status: ${order.order_status}"
        holder.tvOrderDate.text = "Date: ${order.order_date}"

        // Set onClickListener inside onBindViewHolder
        holder.itemView.setOnClickListener {
            val intent = Intent(context, ViewOrderActivity::class.java)
            intent.putExtra("ORDER_ID", order.order_id)  // Pass order ID
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = orders.size

    // Method to update the list of orders
    fun setOrders(newOrders: List<Order>) {
        orders = newOrders
        notifyDataSetChanged()  // Notify that data has changed
    }
}
